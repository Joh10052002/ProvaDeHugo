package Crud.entites;

public interface Identificavel {
	
		public Long getId();
		
		public void setId(Long id);
		
	}


