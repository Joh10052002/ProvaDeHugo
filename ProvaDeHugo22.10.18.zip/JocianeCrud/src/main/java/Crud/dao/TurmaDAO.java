package Crud.dao;

import Crud.Turma;

public class TurmaDAO extends DAO<Turma> {
		
		public TurmaDAO() {
			super(Turma.class);
		}

}
