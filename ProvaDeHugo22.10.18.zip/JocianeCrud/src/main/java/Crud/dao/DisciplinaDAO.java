package Crud.dao;

import Crud.Disciplina;

public class DisciplinaDAO extends DAO<Disciplina> {
	
	public DisciplinaDAO() {
		super (Disciplina.class);
	}

}
