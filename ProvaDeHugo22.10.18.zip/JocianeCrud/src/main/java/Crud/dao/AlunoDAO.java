package Crud.dao;

import Crud.Aluno;

public class AlunoDAO extends DAO<Aluno> {
	
	public AlunoDAO() {
		super(Aluno.class);
	}

}
