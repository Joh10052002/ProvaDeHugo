package Crud.dao;

import Crud.Professor;

public class ProfessorDAO extends DAO<Professor> {
	
	public ProfessorDAO() {
		super(Professor.class);
	}

}

